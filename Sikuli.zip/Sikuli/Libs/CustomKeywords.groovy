
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import java.util.List

import org.sikuli.script.Pattern


def static "com.preeth.cmdprompt.sendKey"(
    	String aKey	) {
    (new com.preeth.cmdprompt()).sendKey(
        	aKey)
}

def static "com.preeth.cmdprompt.explicitWait"(
    	long duration	) {
    (new com.preeth.cmdprompt()).explicitWait(
        	duration)
}

def static "com.preeth.Sikuli.find"(
    	String region	) {
    (new com.preeth.Sikuli()).find(
        	region)
}

def static "com.preeth.Sikuli.click"(
    	String region	) {
    (new com.preeth.Sikuli()).click(
        	region)
}

def static "com.preeth.Sikuli.sendkey"(
    	String label	) {
    (new com.preeth.Sikuli()).sendkey(
        	label)
}

def static "com.preeth.Sikuli.exists"(
    	String image	
     , 	double time	) {
    (new com.preeth.Sikuli()).exists(
        	image
         , 	time)
}

def static "com.preeth.Sikuli.waitforImage"(
    	String image	
     , 	double time	) {
    (new com.preeth.Sikuli()).waitforImage(
        	image
         , 	time)
}

def static "com.preeth.Sikuli.setAutoWaitTimeout"(
    	double sec	) {
    (new com.preeth.Sikuli()).setAutoWaitTimeout(
        	sec)
}

def static "com.preeth.Sikuli.findAll"(
    	String img	) {
    (new com.preeth.Sikuli()).findAll(
        	img)
}

def static "com.preeth.Sikuli.findany"(
    	String img	) {
    (new com.preeth.Sikuli()).findany(
        	img)
}

def static "com.preeth.Sikuli.findanyList"(
    	java.util.List<String> imgs	) {
    (new com.preeth.Sikuli()).findanyList(
        	imgs)
}

def static "com.preeth.Sikuli.findAllCount"(
    	String img	) {
    (new com.preeth.Sikuli()).findAllCount(
        	img)
}

def static "com.preeth.Sikuli.scrollMouseWheelDown"(
    	String img	
     , 	int script	) {
    (new com.preeth.Sikuli()).scrollMouseWheelDown(
        	img
         , 	script)
}

def static "com.preeth.Sikuli.scrollMouseWheelUp"(
    	String img	
     , 	int script	) {
    (new com.preeth.Sikuli()).scrollMouseWheelUp(
        	img
         , 	script)
}

def static "com.preeth.Sikuli.clickSimilarImage"(
    	Pattern img	) {
    (new com.preeth.Sikuli()).clickSimilarImage(
        	img)
}

def static "com.preeth.Sikuli.openExeFile"(
    	String exeFilePath	) {
    (new com.preeth.Sikuli()).openExeFile(
        	exeFilePath)
}

def static "com.preeth.Sikuli.closeFocusedProgram"() {
    (new com.preeth.Sikuli()).closeFocusedProgram()
}
