package com.preeth

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class cmdprompt {

	//	@Keyword
	//	public static int sendKey(String aKey) throws IOException {
	//		int result = 1;
	//		//0 0 L11
	//		//LoggerHelper.out (35, "Send key " + aKey);
	//		System.out.println(aKey);
	//
	//		if (aKey.length ()>0) {
	//			//String cmdline = "C:\\Windows\\System32\\IRClient.exe " + "getServer ( )" + " " + "getRemote ( )" + " " + aKey;// + " 0 0 L05";
	//
	//
	//			//String cmdline = "cmd /c \"start C:\\Users\\preeth\\Desktop\\1.bat && java -version\""+aKey;
	//
	//			String cmdline = aKey;
	//			System.out.println(cmdline);
	//			Process cmd = Runtime.getRuntime().exec(cmdline);
	//			//		  	Runtime.getRuntime().exec("cmd /c \"start mvn -version && java -version\"");
	//
	//			try {
	//				result = cmd.waitFor ( );
	//			} catch (InterruptedException e) {
	//				e.printStackTrace ( );
	//			}
	//
	//			if (result != 0) {
	//				cmd.destroy ( );
	//				//LoggerHelper.out (2, aKey + " could not be send Error: " + cmd.exitValue ( ));
	//				System.out.println(aKey + " could not be send Error: " + cmd.exitValue ( ));
	//			}
	//		}
	//		return result;
	//	}

	@Keyword
	public static int sendKey(String aKey) throws IOException {
		int result = 1;
		System.out.println(aKey);

		if (aKey.length ()>0) {
			String cmdline = aKey;
			System.out.println(cmdline);
			Process cmd = Runtime.getRuntime().exec(cmdline);

			try {
				result = cmd.waitFor();
			} catch (InterruptedException e) {
				e.printStackTrace ( );
			}

			if (result != 0) {
				cmd.destroy ( );
				System.out.println(aKey + " could not be send Error: " + cmd.exitValue ( ));
			}
		}
		return result;
	}

	@Keyword
	public static void explicitWait(long duration) {
		try {
			System.out.println("Wait for " + duration + " milliseconds");
			Thread.sleep(duration);
		} catch (Exception e) {
			System.out.println("Exception raised: " + e.getMessage());
			e.printStackTrace();
		}
	}

}
